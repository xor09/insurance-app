package com.techlabs.insurance.entities;

public enum ClaimStatus {
	APPLIED,
	APPROVED,
	REJECTED
}
