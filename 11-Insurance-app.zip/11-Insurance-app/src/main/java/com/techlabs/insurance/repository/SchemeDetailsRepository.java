package com.techlabs.insurance.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.techlabs.insurance.entities.SchemeDetails;

public interface SchemeDetailsRepository extends JpaRepository<SchemeDetails,Integer>{

}
