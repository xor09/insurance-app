package com.techlabs.insurance.entities;

public enum Status {
	ACTIVE, INACTIVE, PENDING
}
