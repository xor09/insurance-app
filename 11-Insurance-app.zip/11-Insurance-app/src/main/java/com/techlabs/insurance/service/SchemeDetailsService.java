package com.techlabs.insurance.service;


public interface SchemeDetailsService {

}
