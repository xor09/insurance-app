package com.techlabs.insurance.entities;

public enum PaymentType {
	DEBIT_CARD,
	CREDIT_CARD,
}
